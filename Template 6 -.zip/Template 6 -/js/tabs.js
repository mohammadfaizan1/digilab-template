document.addEventListener('DOMContentLoaded', () => {
    new ZinfiTabs({
        'selector': '.zsl-tabs',
        'type': 'vertical',
        'responsiveBreak': 840,
        'activeIndex' : 0
    });
});

"use strict";
function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, t) {
    for (var s = 0; s < t.length; s++) {
        var a = t[s];
        (a.enumerable = a.enumerable || !1), (a.configurable = !0), "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a);
    }
}
function _createClass(e, t, s) {
    return t && _defineProperties(e.prototype, t), s && _defineProperties(e, s), e;
}
var ZinfiTabs = (function () {
    function e(t) {
        _classCallCheck(this, e);
        (this.options = Object.assign({ selector: ".zsl-tabs", type: "horizontal", responsiveBreak: 840, activeIndex: 0 }, t)),
            (this.elems = document.querySelectorAll(this.options.selector)),
            (this.skipIfInitialized = function (e) {
                e.classList.contains("tabs__initialized");
            }),
            this.buildUI(),
            this.handleNavigation(),
            this.handleResponsive();
    }
    return (
        _createClass(e, [
            {
                key: "buildUI",
                value: function () {
                    var e = this;
                    this.elems.forEach(function (t, s) {
                        var a = t,
                            i = a.childNodes,
                            n = [],
                            r = e.options.type;
                        e.skipIfInitialized(a), a.classList.add("style__" + e.options.type), a.classList.add("tabs__initialized");
                        for (var l = 0; l < i.length; l++) {
                            var c = i[l];
                            if (c.nodeType != Node.TEXT_NODE) {
                                c.classList.add("tabs__content");
                                var o = c.dataset.title ? c.dataset.title : "";
                                n.push(o);
                                var _ = c.innerHTML;
                                (c.innerHTML = '<div class="tabs__contentwrapper">' + _ + "</div>"), c.insertAdjacentHTML("afterbegin", '<a class="tabs__navlink">' + o + "</a>");
                            }
                        }
                        var v = "";
                        n.forEach(function (e) {
                            v = v + '<a class="tabs__navlink">' + e + "</a>";
                        }),
                            a.insertAdjacentHTML("afterbegin", '<li class="tabs__nav">' + v + "</li>");
                        var d = Number(e.options.activeIndex);
                        "accordion" != r &&
                            -1 != d &&
                            (d > n.length - 1 &&
                                (console.warn("VANILLA TABS: Active tab number from settings is bigger than tabs count. Please remember, that index starts from Zero! To avoid crashes, activeIndex option was reverted to 0."), (d = 0)),
                            a.querySelectorAll(".tabs__nav > .tabs__navlink")[d].classList.add("is__active"),
                            a.querySelectorAll(".tabs__content")[d].classList.add("is__active"),
                            a.querySelectorAll(".tabs__content > .tabs__navlink")[d].classList.add("is__active"));
                    });
                },
            },
            {
                key: "handleNavigation",
                value: function () {
                    var e = this,
                        t = this.elems,
                        s = this.options.type;
                    t.forEach(function (t, a) {
                        var i = t;
                        e.skipIfInitialized(i),
                            i.addEventListener("click", function (e) {
                                if (e.target && e.target.classList.contains("tabs__navlink")) {
                                    var t;
                                    e.preventDefault(),
                                        (t =
                                            "tabs__nav" == e.target.parentElement.classList
                                                ? Array.prototype.slice.call(e.target.parentElement.children).indexOf(e.target)
                                                : Array.prototype.slice.call(e.target.parentElement.parentElement.children).indexOf(e.target.parentElement) - 1);
                                    var a = i.getElementsByClassName("tabs__content"),
                                        n = i.querySelectorAll(".tabs__nav > .tabs__navlink"),
                                        r = i.querySelectorAll(".tabs__content > .tabs__navlink");
                                    if (("accordion" == s || i.classList.contains("is__responsive")) && e.target.classList.contains("is__active"))
                                        return a[t].classList.remove("is__active"), n[t].classList.remove("is__active"), void r[t].classList.remove("is__active");
                                    for (var l = 0; l < a.length; l++) a[l].classList.remove("is__active");
                                    a[t].classList.add("is__active"),
                                        n.forEach(function (e) {
                                            e.classList.remove("is__active");
                                        }),
                                        n[t].classList.add("is__active"),
                                        r.forEach(function (e) {
                                            e.classList.remove("is__active");
                                        }),
                                        r[t].classList.add("is__active");
                                }
                            });
                    });
                },
            },
            {
                key: "handleResponsive",
                value: function () {
                    var e = this,
                        t = this.elems,
                        s = this.options.type;
                    window.addEventListener("resize", function () {
                        t.forEach(function (t, a) {
                            var i = t,
                                n = i.getElementsByClassName("tabs__content"),
                                r = i.querySelectorAll(".tabs__nav > .tabs__navlink"),
                                l = i.querySelectorAll(".tabs__content > .tabs__navlink");
                            (e.skipIfInitialized(i), window.innerWidth > Number(e.options.responsiveBreak))
                                ? (i.classList.remove("is__responsive"),
                                  "accordion" != s && 0 == i.querySelectorAll(".tabs__navlink.is__active").length && (n[0].classList.add("is__active"), r[0].classList.add("is__active"), l[0].classList.add("is__active")))
                                : i.classList.add("is__responsive");
                        });
                    }),
                        window.dispatchEvent(new Event("resize"));
                },
            },
        ]),
        e
    );
})();